#ifndef TRAINERCARD_H
#define TRAINERCARD_H

#include "Card.h"
#include "PokemonCard.h" // Assurez-vous que ce fichier contient les d�finitions n�cessaires
#include <vector>
#include <string>
#include <iostream> // Ajout pour cout

using namespace std;

class TrainerCard : public Card {
private:
    string trainerEffect;

public:
    // Constructeur
    TrainerCard(const string& name, const string& effect)
        : Card(name), trainerEffect(effect) {}

    // M�thode pour afficher les informations de la carte d'entra�neur
    void displayInfo() const override {
        cout << "Trainer Card: " << cardName << endl;
        cout << "Effect: " << trainerEffect << endl;
    }

    // Appliquer l'effet de la carte d'entra�neur sur les Pok�mon actifs
    void applyEffect(vector<PokemonCard>& actionPokemons) {
        if (trainerEffect == "heal all your action pokemon") {
            for (PokemonCard& p : actionPokemons) {
                p.heal(); // Assurez-vous que PokemonCard poss�de une m�thode heal()
            }
        } else {
            cout << "Unknown effect: " << trainerEffect << endl;
        }
    }

    // M�thode pour obtenir l'effet de la carte
    string getEffect() const {
        return trainerEffect;
    }
};

#endif // TRAINERCARD_H
