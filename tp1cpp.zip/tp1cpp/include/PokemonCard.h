#ifndef POKEMONCARD_H
#define POKEMONCARD_H

#include "Card.h"
#include "EnergyCard.h"
#include <string>
#include <vector>
#include <tuple>
#include <iostream>

using namespace std;

class PokemonCard : public Card {
private:
    string pokemonType;
    string familyName;
    int evolutionLevel;
    int maxHP;
    int hp;
    vector<tuple<int, int, string, int>> attacks; // Tuple pour repr�senter les attaques
    vector<EnergyCard*> attachedEnergies; // Pour stocker les �nergies attach�es

public:
    // Constructeur
    PokemonCard(const string& name, const string& type, const string& family, int level, int maxHP, int currentHP,
                const vector<tuple<int, int, string, int>>& attackList)
        : Card(name), pokemonType(type), familyName(family), evolutionLevel(level), maxHP(maxHP), hp(currentHP), attacks(attackList) {}

    // M�thode pour obtenir le nom du Pok�mon
    string getName() const {
        return cardName;
    }

    // M�thode pour attacher une carte �nergie
    void attachEnergy(EnergyCard* energy) {
        attachedEnergies.push_back(energy);
        cout << "Attached " << energy->getType() << " energy to " << cardName << ".\n";
    }

    // M�thode pour utiliser une attaque
    void useMove(size_t moveIndex, PokemonCard& target) {
        if (moveIndex < attacks.size()) {
            int damage = get<3>(attacks[moveIndex]); // Obtenir les d�g�ts de l'attaque
            target.hp -= damage; // R�duire les HP de la cible
            if (target.hp < 0) {
                target.hp = 0; // S'assurer que les HP ne deviennent pas n�gatifs
            }
            cout << cardName << " used " << get<2>(attacks[moveIndex]) << " and dealt " << damage << " damage to " << target.getName() << ".\n";
        } else {
            cout << "Invalid move index.\n";
        }
    }

    void displayInfo() const override {
        cout << "Nom du Pokemon: " << cardName << endl;
        cout << "Type: " << pokemonType << endl;
        cout << "Famille: " << familyName << endl;
        cout << "Niveau d'�volution: " << evolutionLevel << endl;
        cout << "Points de vie: " << hp << "/" << maxHP << endl;
        for (size_t i = 0; i < attacks.size(); ++i) {
            cout << "Attaque " << i + 1 << " : " << endl;
            cout << "  Co�t en �nergie : " << get<0>(attacks[i]) << endl;
            cout << "  Co�t en �nergie actuel : " << get<1>(attacks[i]) << endl;
            cout << "  Description : " << get<2>(attacks[i]) << endl;
            cout << "  D�g�ts : " << get<3>(attacks[i]) << endl;
        }
    }

    void heal() {
        hp = maxHP; // R�initialiser les HP du Pok�mon � leur maximum
    }
};

#endif // POKEMONCARD_H
