#ifndef CARD_H
#define CARD_H

#include <iostream>
#include <string>

using namespace std;

class Card {
protected:
    string cardName;

public:
    // Constructeur par d�faut
    Card() : cardName("") {}  // Ajoute un constructeur par d�faut si n�cessaire

    // Constructeur avec nom
    Card(const string& name) : cardName(name) {}

    // Fonction virtuelle pure
    virtual void displayInfo() const = 0;

    // Destructeur virtuel
    virtual ~Card() {}
};

#endif // CARD_H


