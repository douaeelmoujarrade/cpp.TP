#ifndef PLAYER_H
#define PLAYER_H

#include "Card.h"
#include "PokemonCard.h"
#include "EnergyCard.h"
#include "TrainerCard.h"
#include <vector>
#include <string>
#include <iostream>

using namespace std;

class Player {
private:
    string playerName;
    vector<Card*> benchCards;
    vector<PokemonCard*> actionCards;

public:
    // Constructeur
    Player(const string& name)
        : playerName(name) {}


    void addCardToBench(Card* card) {
        benchCards.push_back(card);
    }


    void activatePokemonCard(size_t index) {
        if (index < benchCards.size()) {
            PokemonCard* pokemonCard = dynamic_cast<PokemonCard*>(benchCards[index]);
            if (pokemonCard) {
                actionCards.push_back(pokemonCard);
                benchCards.erase(benchCards.begin() + index);
                cout << playerName << " activated " << pokemonCard->getName() << " from the bench.\n";
            } else {
                cout << "The selected card is not a Pok�mon card.\n";
            }
        } else {
            cout << "Invalid index for bench card.\n";
        }
    }


    void attachEnergyCard(size_t benchIndex, size_t actionIndex) {
        if (benchIndex < benchCards.size() && actionIndex < actionCards.size()) {
            EnergyCard* energyCard = dynamic_cast<EnergyCard*>(benchCards[benchIndex]);
            if (energyCard) {
                actionCards[actionIndex]->attachEnergy(energyCard);
                benchCards.erase(benchCards.begin() + benchIndex);
                cout << "Attached " << energyCard->getType() << " energy to " << actionCards[actionIndex]->getName() << ".\n";
            } else {
                cout << "The selected card is not an Energy card.\n";
            }
        } else {
            cout << "Invalid index for bench or action card.\n";
        }
    }

    // Afficher les cartes sur le banc
    void displayBench() const {
        cout << playerName << "'s Bench Cards:\n";
        for (const Card* card : benchCards) {
            card->displayInfo();
        }
    }


    void displayAction() const {
        cout << playerName << "'s Action Cards:\n";
        for (const PokemonCard* card : actionCards) {
            card->displayInfo();
        }
    }


    void attack(size_t attackingCardIndex, size_t moveIndex, Player& opponent, size_t opponentCardIndex) {
        if (attackingCardIndex < actionCards.size() && opponentCardIndex < opponent.actionCards.size()) {
            PokemonCard* attacker = actionCards[attackingCardIndex];
            PokemonCard* defender = opponent.actionCards[opponentCardIndex];
            attacker->useMove(moveIndex, *defender);
        } else {
            cout << "Invalid attack indices.\n";
        }
    }

    // Utiliser une carte d'entra�neur
    void useTrainer(size_t benchIndex) {
        if (benchIndex < benchCards.size()) {
            TrainerCard* trainerCard = dynamic_cast<TrainerCard*>(benchCards[benchIndex]);
            if (trainerCard) {
                trainerCard->useEffect(*this);
                benchCards.erase(benchCards.begin() + benchIndex);
            } else {
                cout << "The selected card is not a Trainer card.\n";
            }
        } else {
            cout << "Invalid index for bench card.\n";
        }
    }

    string getPlayerName() const {
        return playerName;
    }
};

#endif // PLAYER_H
