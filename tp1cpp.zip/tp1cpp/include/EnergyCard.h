#ifndef ENERGYCARD_H
#define ENERGYCARD_H

#include "Card.h"
#include <string>
#include <iostream>

using namespace std;

class EnergyCard : public Card {
private:
    string energyType;

public:
    // Constructeur
    EnergyCard(const string& name, const string& type)
        : Card(name), energyType(type) {}

    // M�thode pour obtenir le type d'�nergie
    string getType() const {
        return energyType;
    }

    void displayInfo() const override {
        cout << "Nom de la carte: " << cardName << endl;
        cout << "Type de l'�nergie: " << energyType << endl;
    }
};

#endif // ENERGYCARD_H
