#include "card.h"
#include "PokemonCard.h"
#include "EnergyCard.h"
#include "TrainerCard.h"
#include "Player.h"
#include <iostream>
#include <string>

using namespace std;

int main() {
    cout << "Classe de base Card implemente avec succes." << endl;

     // Cr�ation d'une carte Pok�mon
    vector<tuple<int, int, string, int>> attacks = {
        {3, 2, "Charge", 30},
        {4, 3, "�clair", 50}
    };

    PokemonCard pikachu("Pikachu", "�lectrique", "Souris", 1, 100, 80, attacks);

    // Affichage des informations de la carte
    pikachu.displayInfo();


    // Cr�ation d'une carte d'�nergie
    EnergyCard electricEnergy("�lectrique");

    // Affichage des informations des cartes
    pikachu.displayInfo();
    cout << "\n";
    electricEnergy.displayInfo();

    PokemonCard charmander("Charmander", "Feu", "L�zard", 1, 90, 50, attacks);

    // Cr�ation d'une carte d'entra�neur
    TrainerCard healTrainer("Professeur Chen", "heal all your action pokemon");

    // Liste des Pok�mon actifs
    vector<PokemonCard> activePokemon = {pikachu, charmander};

    // Affichage des informations des cartes
    cout << "Avant l'effet du Trainer:\n";
    for (const auto& pokemon : activePokemon) {
        pokemon.displayInfo();
        cout << "\n";
    }

    // Application de l'effet du Trainer
    healTrainer.applyEffect(activePokemon);

    cout << "Apr�s l'effet du Trainer:\n";
    for (const auto& pokemon : activePokemon) {
        pokemon.displayInfo();
        cout << "\n";
    }
    // Cr�ation d'un joueur
    Player player("Ash");
    player.addBenchCard(&electricEnergy);
    player.addBenchCard(&healTrainer);
    player.addActionCard(&pikachu);
    player.addActionCard(&charmander);

    // Affichage des informations du joueur avant l'effet du Trainer
    cout << "Avant l'effet du Trainer:\n";
    player.displayInfo();


    // Affichage des informations du joueur apr�s l'effet du Trainer
    cout << "Apr�s l'effet du Trainer:\n";
    player.displayInfo();

    return 0;
}
