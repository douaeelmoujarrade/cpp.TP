#ifndef TRAINERCARD_H
#define TRAINERCARD_H

#include "Card.h"
#include "PokemonCard.h" // Assurez-vous que ce fichier contient les d�finitions n�cessaires
#include <vector>
#include <string>
#include <iostream> // Ajout pour cout

using namespace std;

class TrainerCard : public Card {
private:
    string trainerEffect;

public:
    // Constructeur pour initialiser les attributs
    TrainerCard(const string& name, const string& effect) : Card(name), trainerEffect(effect) {}

    // Impl�mentation de la fonction displayInfo
    void displayInfo() const override {
        cout << "Nom: " << cardName << "\n"
             << "Effet: " << trainerEffect << "\n";
    }

    // Effet du Trainer: Soigner tous les Pok�mon actifs
   void applyEffect(vector<PokemonCard>& activePokemon) {
    if (trainerEffect == "heal all your action pokemon") {
        for (auto& pokemon : activePokemon) {  // Utiliser des r�f�rences pour modifier les objets
            pokemon.heal(); // Appel � la m�thode heal()
        }
    }
}


};

#endif // TRAINERCARD_H
