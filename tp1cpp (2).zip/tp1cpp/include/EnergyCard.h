#ifndef ENERGYCARD_H
#define ENERGYCARD_H

#include "Card.h"
#include <string>
#include <iostream>

using namespace std;

class EnergyCard : public Card {
private:
    string energyType;

public:
    // Constructeur pour initialiser l'�nergie
    EnergyCard(const string& type) : Card("Energy"), energyType(type) {}

    // Impl�mentation de la fonction displayInfo
    void displayInfo() const override {
        cout << "Nom: " << cardName << "\n"
             << "Type d'�nergie: " << energyType << "\n";
    }
};

#endif // ENERGYCARD_H
