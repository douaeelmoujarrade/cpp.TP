#ifndef POKEMONCARD_H
#define POKEMONCARD_H

#include "Card.h"
#include "EnergyCard.h"
#include <string>
#include <vector>
#include <tuple>
#include <iostream>

using namespace std;

class PokemonCard : public Card {
private:
    string pokemonType;
    string familyName;
    int evolutionLevel;
    int maxHP;
    int hp;
    vector<tuple<int, int, string, int>> attacks; // Attaques

public:
    // Constructeur pour initialiser les attributs
    PokemonCard(const string& name, const string& type, const string& family, int evolution, int maxHP, int currentHP,
                const vector<tuple<int, int, string, int>>& attackList)
        : Card(name), pokemonType(type), familyName(family), evolutionLevel(evolution), maxHP(maxHP), hp(currentHP), attacks(attackList) {}

    // Impl�mentation de la fonction displayInfo
    void displayInfo() const override {
        cout << "Nom: " << cardName << "\n"
             << "Type: " << pokemonType << "\n"
             << "Famille: " << familyName << "\n"
             << "Niveau d'�volution: " << evolutionLevel << "\n"
             << "HP: " << hp << "/" << maxHP << "\n";

        cout << "Attaques: " << endl;
        for (size_t i = 0; i < attacks.size(); ++i) {
            auto& [cost, currentCost, description, damage] = attacks[i];
            cout << "  Attaque " << i + 1 << ": " << description << "\n"
                 << "    Co�t en �nergie: " << cost << ", Co�t actuel: " << currentCost << "\n"
                 << "    D�g�ts: " << damage << "\n";
        }
    }

    // M�thode pour soigner le Pok�mon
    void heal() {
        hp = maxHP;  // R�initialiser les points de vie � leur valeur maximale
        cout << cardName << " a �t� soign� et a maintenant " << hp << " HP.\n";
    }
};

#endif // POKEMONCARD_H
