#ifndef CARD_H
#define CARD_H

#include <iostream>
#include <string>

using namespace std;

class Card {
protected:
    string cardName; // Nom de la carte

public:
    // Constructeur pour initialiser le nom de la carte
    Card(const string& name) : cardName(name) {}

    // Destructeur virtuel
    virtual ~Card() {}

    // Fonction virtuelle pure pour afficher les informations de la carte
    virtual void displayInfo() const = 0;

    // Getter pour le nom de la carte
    string getCardName() const {
        return cardName;
    }
};


#endif // CARD_H


