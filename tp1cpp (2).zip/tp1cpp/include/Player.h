#ifndef PLAYER_H
#define PLAYER_H

#include "Card.h"
#include "PokemonCard.h"
#include "EnergyCard.h"
#include "TrainerCard.h"
#include <vector>
#include <string>
#include <iostream>

using namespace std;

class Player {
private:
    string playerName;
    vector<Card*> benchCards; // Cartes en r�serve
    vector<PokemonCard*> actionCards; // Cartes Pok�mon en action

public:
    // Constructeur pour initialiser les attributs
    Player(const string& name) : playerName(name) {}

    // Ajouter une carte � la r�serve
    void addBenchCard(Card* card) {
        benchCards.push_back(card);
    }

    // Ajouter une carte Pok�mon � l'action
    void addActionCard(PokemonCard* pokemon) {
        actionCards.push_back(pokemon);
    }

    // Afficher les informations du joueur
    void displayInfo() const {
        cout << "Joueur: " << playerName << "\n";
        cout << "Cartes en r�serve: \n";
        for (const auto& card : benchCards) {
            card->displayInfo();
            cout << "\n";
        }

        cout << "Cartes en action: \n";
        for (const auto& pokemon : actionCards) {
            pokemon->displayInfo();
            cout << "\n";
              }
    }

    // Obtenir les cartes Pok�mon en action
    vector<PokemonCard*>& getActionCards() {
        return actionCards;
    }
};


#endif // PLAYER_H
