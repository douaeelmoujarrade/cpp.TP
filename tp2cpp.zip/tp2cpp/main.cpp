#include <iostream>
#include "TimeSeriesGenerator.h"
#include "GaussianGenerator.h"
#include "StepGenerator.h"
#include "SinWaveGenerator.h"
#include "TimeSeriesDataset.h"

using namespace std;

int main() {
    // G�n�rateur Gaussien
    GaussianGenerator gsg(42, 5.0, 2.0); // Graine 42, moyenne 5, �cart type 2
    vector<double> gaussianSeries = gsg.generateTimeSeries(10); // G�n�ration de 10 valeurs
    cout << "Gaussian Series: ";
    TimeSeriesGenerator::printTimeSeries(gaussianSeries);

    // G�n�rateur de sauts
    StepGenerator stepGen(42); // Initialisation avec une graine
    vector<double> stepSeries = stepGen.generateTimeSeries(10); // G�n�ration de 10 valeurs
    cout << "Step Series: ";
    TimeSeriesGenerator::printTimeSeries(stepSeries);

    SinWaveGenerator sinGen(42, 2.0, 0.5, 1.0);
    vector<double> sinSeries = sinGen.generateTimeSeries(10); // G�n�re 10 valeurs
    cout << "Sinusoidal Series: ";
    TimeSeriesGenerator::printTimeSeries(sinSeries);



    TimeSeriesDataset dataset(true, true); // Avec normalisation Z

    vector<double> series1 = {1.0, 2.0, 3.0, 4.0};
    vector<double> series2 = {2.0, 3.0, 4.0, 5.0};

    dataset.addTimeSeries(series1, 0);
    dataset.addTimeSeries(series2, 1);

    cout << "Dataset apr�s normalisation :" << endl;
    dataset.printDataset();

    // Calcul de la distance euclidienne entre deux s�ries
    double distance = TimeSeriesDataset::euclideanDistance(series1, series2);
    cout << "Distance euclidienne entre series1 et series2 : " << distance << endl;


    return 0;
}

