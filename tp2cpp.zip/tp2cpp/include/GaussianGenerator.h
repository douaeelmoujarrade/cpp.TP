#ifndef GAUSSIANGENERATOR_H
#define GAUSSIANGENERATOR_H


#include <iostream>
#include <vector>
#include <cmath> // Pour sqrt, log et cos
#include <random> // Pour rand()
#include "TimeSeriesGenerator.h"

using namespace std;

class GaussianGenerator : public TimeSeriesGenerator {
private:
    double mean;   // Moyenne de la distribution
    double stdDev; // �cart type de la distribution

public:
    // Constructeur par d�faut
    GaussianGenerator() : TimeSeriesGenerator(), mean(0.0), stdDev(1.0) {}

    // Constructeur param�tr�
    GaussianGenerator(int seedValue, double meanValue, double stdDevValue)
        : TimeSeriesGenerator(seedValue), mean(meanValue), stdDev(stdDevValue) {}

    // Impl�mentation de la fonction generateTimeSeries
    vector<double> generateTimeSeries(int size) override {
        vector<double> series;
        series.reserve(size);

        // Initialisation du g�n�rateur pseudo-al�atoire avec la graine
        srand(seed);

        for (int i = 0; i < size; ++i) {
            // M�thode de Box-Muller pour g�n�rer deux nombres gaussiens
            double u1 = ((double)rand() / RAND_MAX); // Uniforme [0, 1)
            double u2 = ((double)rand() / RAND_MAX); // Uniforme [0, 1)
            double z0 = sqrt(-2.0 * log(u1)) * cos(2.0 * M_PI * u2);

            // Appliquer les param�tres de la distribution (moyenne et �cart type)
            double value = mean + z0 * stdDev;
            series.push_back(value);
        }
        return series;
    }

    // Destructeur
    ~GaussianGenerator() override = default;
};


#endif // GAUSSIANGENERATOR_H
