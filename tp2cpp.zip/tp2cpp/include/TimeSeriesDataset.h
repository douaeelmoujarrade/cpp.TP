#ifndef TIME_SERIES_DATASET_H
#define TIME_SERIES_DATASET_H

#include <vector>
#include <cmath>
#include <iostream>
using namespace std;

class TimeSeriesDataset {
private:
    bool znormalize;
    bool isTrain;
    vector<vector<double>> data;
    vector<int> labels;
    int maxLength;
    int numberOfSamples;

    vector<double> zNormalize(const vector<double>& series) const;

public:
    TimeSeriesDataset(bool znormalize = false, bool isTrain = false);

    void addTimeSeries(const vector<double>& series, int label);
    const vector<vector<double>>& getData() const;
    const vector<int>& getLabels() const;
    void printDataset() const;

    // M�thode statique pour calculer la distance euclidienne
    static double euclideanDistance(const vector<double>& x, const vector<double>& y);

    ~TimeSeriesDataset() = default;
};

#endif // TIME_SERIES_DATASET_H
