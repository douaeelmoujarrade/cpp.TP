#ifndef STEP_GENERATOR_H
#define STEP_GENERATOR_H

#include "TimeSeriesGenerator.h"
#include <vector>
using namespace std;

class StepGenerator : public TimeSeriesGenerator {
public:
    // Constructeur par d�faut
    StepGenerator();

    // Constructeur param�tr�
    StepGenerator(int seedValue);

    // Impl�mentation de la fonction virtuelle pure
    vector<double> generateTimeSeries(int size) override;

    // Destructeur
    ~StepGenerator() override = default;
};

#endif // STEP_GENERATOR_H
