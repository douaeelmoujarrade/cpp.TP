#ifndef TIMESERIESGENERATOR_H
#define TIMESERIESGENERATOR_H


#include <iostream>
#include <vector>
#include <iomanip> // Pour un affichage pr�cis des valeurs

using namespace std;

class TimeSeriesGenerator {
protected:
    int seed; // Attribut pour stocker la graine
public:
    // Constructeur par d�faut
    TimeSeriesGenerator() : seed(0) {}

    // Constructeur param�tr�
    TimeSeriesGenerator(int seedValue) : seed(seedValue) {}

    // Fonction virtuelle pure pour g�n�rer une s�rie temporelle
    virtual vector<double> generateTimeSeries(int size) = 0;

    // Fonction statique pour imprimer une s�rie temporelle
    static void printTimeSeries(const vector<double>& series) {
        for (double value : series) {
            cout << fixed << setprecision(2) << value << " ";
        }
        cout << endl;
    }

    // Destructeur virtuel
    virtual ~TimeSeriesGenerator() {}
};


#endif // TIMESERIESGENERATOR_H
