#ifndef SIN_WAVE_GENERATOR_H
#define SIN_WAVE_GENERATOR_H

#include "TimeSeriesGenerator.h"
#include <vector>
using namespace std;

class SinWaveGenerator : public TimeSeriesGenerator {
private:
    double amplitude; // Amplitude de l'onde
    double frequency; // Fr�quence de l'onde
    double phase;     // Phase initiale

public:
    // Constructeur par d�faut
    SinWaveGenerator();

    // Constructeur param�tr�
    SinWaveGenerator(int seedValue, double amplitudeValue, double frequencyValue, double phaseValue);

    // Impl�mentation de la fonction virtuelle pure
    vector<double> generateTimeSeries(int size) override;

    // Destructeur
    ~SinWaveGenerator() override = default;
};

#endif // SIN_WAVE_GENERATOR_H

