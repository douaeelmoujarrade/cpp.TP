#include "SinWaveGenerator.h"
#include <cmath> // Pour sin()

// Constructeur par d�faut
SinWaveGenerator::SinWaveGenerator()
    : TimeSeriesGenerator(), amplitude(1.0), frequency(1.0), phase(0.0) {}

// Constructeur param�tr�
SinWaveGenerator::SinWaveGenerator(int seedValue, double amplitudeValue, double frequencyValue, double phaseValue)
    : TimeSeriesGenerator(seedValue), amplitude(amplitudeValue), frequency(frequencyValue), phase(phaseValue) {}

// Impl�mentation de generateTimeSeries
vector<double> SinWaveGenerator::generateTimeSeries(int size) {
    vector<double> series;
    series.reserve(size);

    for (int i = 0; i < size; ++i) {
        double value = amplitude * sin(frequency * i + phase);
        series.push_back(value);
    }

    return series;
}
