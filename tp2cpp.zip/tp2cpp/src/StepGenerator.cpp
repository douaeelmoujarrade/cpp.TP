#include "StepGenerator.h"
#include <cstdlib> // Pour rand() et srand()

// Constructeur par d�faut
StepGenerator::StepGenerator() : TimeSeriesGenerator() {}

// Constructeur param�tr�
StepGenerator::StepGenerator(int seedValue) : TimeSeriesGenerator(seedValue) {}

// Impl�mentation de generateTimeSeries
vector<double> StepGenerator::generateTimeSeries(int size) {
    vector<double> series;
    series.reserve(size);

    srand(seed); // Initialisation du g�n�rateur pseudo-al�atoire avec la graine

    double currentValue = 0.0;
    series.push_back(currentValue); // Premi�re valeur est 0

    for (int i = 1; i < size; ++i) {
        if (rand() % 2 == 0) {
            // Avec une probabilit� de 50%, on choisit une nouvelle valeur al�atoire entre 0 et 100
            currentValue = rand() % 101; // G�n�re un entier entre 0 et 100
        }
        // Sinon, la valeur pr�c�dente est conserv�e
        series.push_back(currentValue);
    }

    return series;
}
