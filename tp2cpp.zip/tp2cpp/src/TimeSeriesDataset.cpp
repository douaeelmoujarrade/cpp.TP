#include "TimeSeriesDataset.h"

// Constructeur
TimeSeriesDataset::TimeSeriesDataset(bool znormalize, bool isTrain)
    : znormalize(znormalize), isTrain(isTrain), maxLength(0), numberOfSamples(0) {}

// Normalisation Z
vector<double> TimeSeriesDataset::zNormalize(const vector<double>& series) const {
    double mean = 0.0, stdDev = 0.0;

    // Calcul de la moyenne
    for (double value : series) mean += value;
    mean /= series.size();

    // Calcul de l'�cart type
    for (double value : series) stdDev += (value - mean) * (value - mean);
    stdDev = sqrt(stdDev / series.size());

    // Normalisation
    vector<double> normalizedSeries;
    for (double value : series) {
        normalizedSeries.push_back((stdDev != 0) ? (value - mean) / stdDev : 0.0);
    }

    return normalizedSeries;
}

// Ajout d'une s�rie temporelle
void TimeSeriesDataset::addTimeSeries(const vector<double>& series, int label) {
    vector<double> processedSeries = series;

    if (znormalize) {
        processedSeries = zNormalize(series);
    }

    data.push_back(processedSeries);
    labels.push_back(label);

    maxLength = max(maxLength, static_cast<int>(series.size()));
    numberOfSamples++;
}

// Distance euclidienne
double TimeSeriesDataset::euclideanDistance(const vector<double>& x, const vector<double>& y) {
    if (x.size() != y.size()) {
        throw invalid_argument("Les s�ries temporelles doivent avoir la m�me taille pour calculer la distance euclidienne.");
    }

    double sum = 0.0;
    for (size_t i = 0; i < x.size(); ++i) {
        sum += (x[i] - y[i]) * (x[i] - y[i]);
    }

    return sqrt(sum);
}

// Affichage des s�ries
void TimeSeriesDataset::printDataset() const {
    for (size_t i = 0; i < data.size(); ++i) {
        cout << "Series " << i + 1 << " (Label: " << labels[i] << "): ";
        for (double value : data[i]) {
            cout << value << " ";
        }
        cout << endl;
    }
}
